public class ArmaduraDePlata extends Armadura{

	private int defensa;

// constructor

	public ArmaduraDePlata(int nivel){

		super(nivel);

	}

//set defensa

	public void setDefensa(int nivel){

		int def;
		def = (nivel * 5);

		this.defensa = def;

	}

//get defensa

	public int getDefensa(){

		return defensa;

	}
	
}
interface Personaje{

//set nombre 

	void setNombre(String nombre);

//get nombre

	String getNombre();

//set nivel

	void setNivel(int nivel);

//get nivel

	int getNivel();

//set HP

	void setHp(int hp);

//get HP

	int getHp();

//set ataque

	void setAtaque(int ataque);

//get ataque

	int getAtaque();

//set defensa

	void setDefensa(int defensa);

//get defensa

	int getDefensa();

}// interface

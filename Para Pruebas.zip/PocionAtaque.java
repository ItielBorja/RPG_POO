public class PocionAtaque extends Pociones{

	public PocionAtaque(){

		
	}
	
}
public class Item{
	
	private String 	nombre;
	private String 	tipo;
	private String 	descripcion;

//Constructor

	public Item(){

		
	}

//set nombre 

	public void setNombre(String nombre){

		this.nombre= nombre;

	}

//get nombre

	public String getNombre(){

		return nombre;

	}

//set tipo

	public void setTipo(String tipo){

		this.tipo= tipo;

	}

//get tipo

	public String getTipo(){

		return tipo;

	}

//set descripcion 

	public void setDescripcion(String descripcion){

		this.descripcion= descripcion;

	}

//get descripcion

	public String getDescripcion(){

		return descripcion;

	}


}// clase

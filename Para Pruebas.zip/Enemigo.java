public class Enemigo implements Personaje{
	
	private String 	nombre;
	private int 	nivel;
	private int 	hp;
	private int 	ataque;
	private int 	defensa;

//constructor 

	public Enemigo(String nombre, int nivel, int vida, int ataque, int defensa){

		this.nombre 	= nombre;
		this.nivel 		= nivel;
		this.hp 		= vida;
		this.ataque 	= ataque;
		this.defensa 	= defensa;

	}

//set nombre 

	public void setNombre(String nombre){

		this.nombre= nombre;

	}

//get nombre

	public String getNombre(){

		return nombre;

	}

//set nivel

	public void setNivel(int nivel){

		
		this.nivel = nivel;

	}

//get nivel

	public int getNivel(){

		return nivel;

	}

//set HP

	public void setHp(int hp){

		this.hp= hp;

	}

//get HP

	public int getHp(){

		return hp;

	}

//set ataque

	public void setAtaque(int ataque){

		this.ataque= ataque;

	}

//get ataque

	public int getAtaque(){

		return ataque;

	}

//set defensa

	public void setDefensa(int defensa){

		this.defensa= defensa;

	}

//get defensa

	public int getDefensa(){

		return defensa;

	}

}// clase

public class PocionVida extends Pociones{

	public PocionVida(){


	}
	
}
public class Bruja extends Enemigo{

// constructor

	public Bruja(String nombre, int nivel){

		//String nombre, int nivel, int vida, int ataque, int defensa
		super(nombre, nivel, 150, 70, 15);
		
	}

}// clase

import java.util.Scanner;

public class Main{
	
	public static void main (String [] args){

		String nombre;
		int aleatorio = 0;
		int nivel = 1;
		int contV = 0;
		int contDO = 0;
		int contDP = 0;
		int contA = 0;
		int contW = 0;

		boolean repetir = true;
		boolean fin = true;
		boolean batallaT = true;
		boolean batallaB = true; 
		boolean batallaM = true;
		boolean primeraVezT = true;
		boolean primeraVezB = true;
		boolean primeraVezM = true;

		boolean win = false;
		boolean loser = false;

		int vida;
		int defensa;
		int ataque;
		int puntos;

// Objetos

		Scanner in = new Scanner(System.in); //Scanner
		Jugador player; //jugador
		Troll troll; // trol 
		Bruja bruja; // bruja
		Mago mago; // mago
		PocionVida pocionV [] 			= new PocionVida[3]; // pocion vida
		PocionAtaque pocionA [] 		= new PocionAtaque[3]; // pocion ataque
		ArmaduraDeOro armaduraO [] 		= new ArmaduraDeOro[3]; // armadura de oro 
		ArmaduraDePlata armaduraP [] 	= new ArmaduraDePlata[3]; // armadura de plata
		Arma weapon [] 					= new Arma[3]; // armas

//Inicializamos 

		System.out.println("Bienvenido a UNA CARRERA POR LA VIDA");
		System.out.println("Dime tu nombre, por favor");
		nombre = in.nextLine(); 
		player = new Jugador(nombre);

	while (fin){

		vida 	= player.getHp();
		defensa = player.getDefensa();
		ataque 	= player.getAtaque();
		nivel 	= player.getNivel();
		puntos 	= player.getPuntos();

		while (repetir){

			System.out.println("Es momento de tirar el dado");

			aleatorio = (int) (Math.random() * 6) + 1;
			System.out.println(aleatorio);

			if (aleatorio == 2 && contV == 3){

				System.out.println("Lo siento, te toco una pocion de vida pero ya no tienes espacios vacios para esa pocion, vuelve a tirar el dado");
				repetir = true;

			}else{

			if (aleatorio == 3 && contDO == 3){

				System.out.println("Lo siento, te toco una armadura de ORO pero ya no tienes espacios vacios para esa armadura, vuelve a tirar el dado");
				repetir = true;

			}else{

			if (aleatorio == 4 && contW == 3){

				System.out.println("Lo siento, te toco una arma pero ya no tienes espacios vacios para armas, vuelve a tirar el dado");
				repetir = true;

			}else{

			if (aleatorio == 5 && contA == 3){

				System.out.println("Lo siento, te toco una pocion de ataque pero ya no tienes espacios vacios para esa pocion, vuelve a tirar el dado");
				repetir = true;

			}else{

			if (aleatorio == 6 && contDP == 3){

				System.out.println("Lo siento, te toco una armadura de PLATA pero ya no tienes espacios vacios para esa armadura, vuelve a tirar el dado");
				repetir = true;

			}else{

				repetir = false;

			}// If aramdura plata
			}// IF pocion de ataque 
			}// IF armas
			} // if armadura ORO
			}// if poción vida 

		}// while repetir tirar el dado 

// selección del dado 

		switch (aleatorio) {

			case 1:


				System.out.println("Te toco 1, por lo que te mueves al siguiente Stage");
				player.setNivel(nivel + 1);
				repetir = true;

			break;

			case 2:

				pocionV[contV] = new PocionVida(); // cuidado definir arreglo
				pocionV[contV].setAumento(player.getNivel());
				System.out.println("Te toco 2, por lo que obtuviste una pocion de vida que te aumentara "+pocionV[contV].getAumento()+ " de vida");
				player.setHp(vida + pocionV[contV].getAumento());

				contV = contV +1;
				repetir = true;

			break;

			case 3:

				armaduraO[contDO] = new ArmaduraDeOro(player.getNivel());
				armaduraO[contDO].setDefensa(player.getNivel());
				System.out.println("Te toco 3, por lo que obtuviste una armadura de ORO que te aumentara "+armaduraO[contDO].getDefensa()+ " de defensa");
				player.setDefensa(defensa + armaduraO[contDO].getDefensa());

				contDO = contDO + 1;
				repetir = true;

			break;

			case 4:

				weapon[contW] = new Arma(player.getNivel());
				weapon[contW].setDano();
				System.out.println("Te toco 4, por lo que obtuviste una nueva Arma que te aumentara "+weapon[contW].getDano()+ " el dano de tu ataque");
				player.setAtaque(ataque + weapon[contW].getDano());

				contW = contW + 1;
				repetir = true;

			break;

			case 5:

				pocionA[contA] = new PocionAtaque(); 
				pocionA[contA].setAumento(player.getNivel());
				System.out.println("Te toco 5, por lo que obtuviste una pocion de ataque que te aumentara "+pocionA[contA].getAumento()+ " de ataque");
				player.setAtaque(ataque + pocionA[contA].getAumento());

				contA = contA +1;
				repetir = true;

			break;

			case 6:

				armaduraP[contDP] = new ArmaduraDePlata(player.getNivel());
				armaduraP[contDP].setDefensa(player.getNivel());
				System.out.println("Te toco 6, por lo que obtuviste una armadura de PLATA que te aumentara "+armaduraP[contDP].getDefensa()+ " de defensa");
				player.setDefensa(defensa + armaduraP[contDP].getDefensa());

				contDP = contDP + 1;
				repetir = true;

			break;

			default:

				System.out.println("Error aleatorio");

			break;

		}// switch aleatorio

// Imprimir 

		System.out.println("\nTu vida "+player.getHp());
		System.out.println("Tu defensa "+player.getDefensa());
		System.out.println("Tu ataque "+player.getAtaque());
		System.out.println("Tu nivel "+player.getNivel());
		System.out.println("Tus puntos "+player.getPuntos()+" \n");

// escoger mapa 

		switch (player.getNivel()){

			case 1:

				//Sigue en el inicio
				System.out.println("");

			break;

			case 2:

				if (primeraVezT){

					System.out.println("BIENVENIDO al Stage 1 donde tendras que enfrentar al temible TROLL");
					troll = new Troll("Troll", player.getNivel());
					primeraVezT = false;

					while(batallaT){

						System.out.println("\n Tu turno de atacar al Troll \n");
						troll.setHp(troll.getHp() + troll.getDefensa() - player.getAtaque());
						System.out.println("Tu vida " + player.getHp());
						System.out.println("La vida del Troll " + troll.getHp());

						if (troll.getHp() <= 0) {
							
							System.out.println("FELICIDADES, has derrotado al TROLL conseguiste 30 puntos");
							player.setPuntos(puntos + 30);
							batallaT = false;

						}else{

							System.out.println("\n El turno del Troll para atacarte \n");
							player.setHp(player.getHp() + player.getDefensa() - troll.getAtaque());
							System.out.println("Tu vida " + player.getHp());
							System.out.println("La vida del Troll " + troll.getHp());

							if (player.getHp() <= 0) {
								
								System.out.println("GAME OVER, te han derrotado :( ");
								fin = false;
								batallaT = false;

							}//derrota
						}// victoria
					}// while batalla
				}// primera vez en el nivel

			break;

			case 3:

				if(primeraVezB){

					System.out.println("BIENVENIDO al Stage 2 donde tendras que enfrentar a la implacable BRUJA");
					bruja = new Bruja("Bruja", player.getNivel());
					primeraVezB = false;

					while(batallaB){

						System.out.println("\n Tu turno de atacar a la bruja \n");
						bruja.setHp(bruja.getHp() + bruja.getDefensa() - player.getAtaque());
						System.out.println("Tu vida " + player.getHp());
						System.out.println("La vida del bruja " + bruja.getHp());

						if (bruja.getHp() <= 0){

							System.out.println("FELICIDADES, has derrotado a la bruja conseguiste 50 puntos");
							player.setPuntos(puntos + 50);
							batallaB = false;

						}else{

							System.out.println("\n El turno de la bruja para atacarte \n");
							player.setHp(player.getHp() + player.getDefensa() - bruja.getAtaque());
							System.out.println("Tu vida " + player.getHp());
							System.out.println("La vida del bruja " + bruja.getHp());

							if (player.getHp() <= 0) {
							
								System.out.println("GAME OVER, te han derrotado :( ");
								fin = false;
								batallaB = false;

							}//derrota
						}// victoria
					}// while batalla
				}//primera vez en el nivel

			break;

			case 4:

				if (primeraVezM){

					System.out.println("FELICIDADES has llegado al ultimo nivel donde tendrás que enfrentar al terririfico MAGO");
					mago = new Mago("Mago", player.getNivel());
					primeraVezM = false;

					while(batallaM){

						System.out.println("\n Tu turno de atacar al mago \n");
						mago.setHp(mago.getHp() + mago.getDefensa() - player.getAtaque());
						System.out.println("Tu vida " + player.getHp());
						System.out.println("La vida del mago " + mago.getHp());


						if (mago.getHp() <= 0){

							System.out.println("FELICIDADES, has derrotado al mago conseguiste 100 puntos");
							player.setPuntos(puntos + 100);
							batallaM = false;
							win = true;
							fin = false;

						}else{

							System.out.println("\n El turno del mago para atacarte \n");
							player.setHp(player.getHp() + player.getDefensa() - mago.getAtaque());
							System.out.println("Tu vida " + player.getHp());
							System.out.println("La vida del mago " + mago.getHp());

							if (player.getHp() <= 0) {
							
								System.out.println("GAME OVER, te han derrotado :( ");
								fin = false;
								loser = true;
								batallaM = false;

							}// derrota
						}// victoria
					}// while batalla
				}// Primera vez en el nivel

			break;

			default:

				System.out.println("Error nivel");

			break;

		}// switch nivel 

		if (win){

			System.out.println("BIEN HECHO, has ganado el juego. Estos son tus estadisticas: \n");
			System.out.println("Vida: "+ player.getHp());
			System.out.println("Defensa: "+player.getDefensa());
			System.out.println("Ataque: "+player.getAtaque());
			System.out.println("Nivel: "+player.getNivel());
			System.out.println("Puntos: "+player.getPuntos());

		}// vistoria 

		if (loser){

			System.out.println("BIEN HECHO, has ganado el juego. Estos son tus estadisticas: \n");
			System.out.println("Vida: "+ player.getHp());
			System.out.println("Defensa: "+player.getDefensa());
			System.out.println("Ataque: "+player.getAtaque());
			System.out.println("Nivel: "+player.getNivel());
			System.out.println("Puntos: "+player.getPuntos());

		}// derrota

	}// while FIN


	}// main

}// clase
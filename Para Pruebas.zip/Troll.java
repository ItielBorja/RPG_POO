public class Troll extends Enemigo{

//constructor

	public Troll(String nombre, int nivel){

		//String nombre, int nivel, int vida, int ataque, int defensa

		super(nombre, nivel, 75, 35, 15);
		
	}

}// clase

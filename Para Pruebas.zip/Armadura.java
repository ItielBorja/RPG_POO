public class Armadura extends Item{
	
	private int nivel;
	private int especialidad;

//constructor

	public Armadura(int nivel){
		
		this.nivel=nivel;

	}

//set nivel

	public void setNivel(int nivel){

		
		this.nivel = nivel;

	}

//get nivel

	public int getNivel(){

		return nivel;

	}



//set especialidad

	public void setEspecialidad(int especialidad){

		
		this.especialidad = especialidad;

	}

//get especialidad

	public int getEspecialidad(){

		return especialidad;

	}


}//clase 

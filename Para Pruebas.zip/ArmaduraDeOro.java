public class ArmaduraDeOro extends Armadura{

	private int defensa;

// constructor

	public ArmaduraDeOro(int nivel){

		super(nivel);

	}

	//set defensa

	public void setDefensa(int nivel){

		int def;
		def = (nivel * 10);

		this.defensa = def;

	}

//get defensa

	public int getDefensa(){

		return defensa;

	}
	
}
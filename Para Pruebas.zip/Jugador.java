public class Jugador implements Personaje{
	
	private Arma 		arma;
	private Armadura 	armadura;
	private int 		puntos;
	private Pociones [] pociones;

	private String 	nombre;
	private int 	nivel;
	private int 	hp;
	private int 	ataque;
	private int 	defensa;

//constructor 

	public Jugador(String nombre){

		this.nombre 	= nombre;
		this.nivel 		= 1;
		this.hp 		= 100;
		this.ataque 	= 25;
		this.defensa 	= 10;
		this.puntos 	= 0;

	}

//set Arma

	public void setArma(Arma arma){

		this.arma= arma;

	}

//get arma

	public Arma getArma(){

		return arma;

	}

//set armadura

	public void setArmadura(Armadura armadura){

		this.armadura = armadura;

	}

//get armadura

	public Armadura getArmadura(){

		return armadura;

	}

//set puntos

	public void setPuntos(int puntos){

		this.puntos = puntos;

	}

//get puntos

	public int getPuntos(){

		return puntos;
	}

//set Pocion 

	public void setPociones(Pociones [] pociones){

		this.pociones = pociones;

	}

//get Pocion

	public Pociones [] getPociones(){

		return pociones;

	}

//set nombre 

	public void setNombre(String nombre){

		this.nombre= nombre;

	}

//get nombre

	public String getNombre(){

		return nombre;

	}

//set nivel

	public void setNivel(int nivel){

		
		this.nivel = nivel;

	}

//get nivel

	public int getNivel(){

		return nivel;

	}

//set HP

	public void setHp(int hp){

		this.hp= hp;

	}

//get HP

	public int getHp(){

		return hp;

	}

//set ataque

	public void setAtaque(int ataque){

		this.ataque= ataque;

	}

//get ataque

	public int getAtaque(){

		return ataque;

	}

//set defensa

	public void setDefensa(int defensa){

		this.defensa= defensa;

	}

//get defensa

	public int getDefensa(){

		return defensa;

	}


}//clase

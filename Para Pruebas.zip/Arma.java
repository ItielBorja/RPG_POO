public class Arma extends Item{
	
	private int nivel;
	private int dano;

//constructor

	public Arma(int nivel){

		this.nivel=nivel;
		this.dano = 0;
		
	}
//set dano
	public void setDano(){

		int ataque;
		ataque = (int) (Math.random() * 15) + 1;
		this.dano = ataque;
	}
//get dano
	public int getDano(){
		return dano;
	}
//set nivel

	public void setNivel(int nivel){

		
		this.nivel = nivel;

	}

//get nivel

	public int getNivel(){

		return nivel;

	}



}// clase 

public class Mago extends Enemigo{

//constructor 

	public Mago(String nombre, int nivel){

		//String nombre, int nivel, int vida, int ataque, int defensa
		super(nombre, nivel, 400, 100, 50);
		
	}
	
}// clase
public class Pociones extends Item{
	
	private int especialidad;
	private int aumento;

//constructor

	public Pociones(){
		
		
	}

//set aumento

	public void setAumento(int nivel){

		int aleatorio;

		aleatorio = (int) (Math.random() * 20) + 1;
		aumento = (aleatorio*nivel);

		this.aumento = aumento;

	}

//get aumento

	public int getAumento(){

		return aumento;

	}

//set especialidad

	public void setEspecialidad(int especialidad){

		
		this.especialidad = especialidad;

	}

//get especialidad

	public int getEspecialidad(){

		return especialidad;

	}



}//clase
